import 'package:chaloapp/screen/set_screen/components/body.dart';
import 'package:flutter/material.dart';

class SetScreen extends StatelessWidget {
  const SetScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body:Body() ,
    );
  }
}
