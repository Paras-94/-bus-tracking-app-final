final flightsAvailableJson = [
  {
    "id": "1",
    "logo": "assets/images/companies_logo/gol_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": false,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
    ],
  },
  {
    "id": "2",
    "logo": "assets/images/companies_logo/latam_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": true,
      },
    ],
  },
  {
    "id": "3",
    "logo": "assets/images/companies_logo/gol_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": true,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
    ],
  },
  {
    "id": "4",
    "logo": "assets/images/companies_logo/gol_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": false,
      },
      {
        "available": true,
      },
    ],
  },
  {
    "id": "5",
    "logo": "assets/images/companies_logo/latam_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
    ],
  },
  {
    "id": "6",
    "logo": "assets/images/companies_logo/latam_logo.png",
    "price": 190.90,
    "title": "Brazil to England",
    "seats": [
      {
        "available": false,
      },
      {
        "available": true,
      },
      {
        "available": false,
      },
      {
        "available": false,
      },
      {
        "available": true,
      },
    ],
  },
];
